package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import modelo.despesaPublica;

public class DAO {

	public Connection getConnection(){
		
		Connection conecta = null;
		
		try{
			
		String url =  "jdbc:sqlserver://nemesis:1433;databaseName=BD_PORTALTRANSPARENCIA;user=UserBetunelEcm;password=$userbetunelecm#";
		
	    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				
	    conecta =  DriverManager.getConnection(url);								
		
		}
		catch(ClassNotFoundException ex1){
			
			ex1.printStackTrace();
			
		}
		catch (SQLException ex)
	    {
	        
	        ex.printStackTrace();
	    }
		return conecta;
	}
	
	public void  criadespesa(despesaPublica despesa){
		
		Connection conectado = getConnection();
		
		String sql = "INSERT INTO DESPESAS_PUBLICAS_V2 ";
		       sql+= "( codigoFavorecido, data, documento, documentoResumido, especie, fase, favorecido, favorecidoIntermediario, localizadorGasto, nomeFavorecido, orgao, orgaoSuperior, subtitulo, ufFavorecido, ug, valor, uo, grupo, elemento, modalidade, favorecidoListaFaturas, empenho, empenhoResumido )";
		       sql+= "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		try {
			
			PreparedStatement stmt = conectado.prepareStatement(sql);
			                  stmt.setString(1, despesa.getCodigoFavorecido());
			                  stmt.setDate  (2, despesa.getData());
			                  stmt.setString(3, despesa.getDocumento());
			                  stmt.setString(4, despesa.getDocumentoResumido());
			                  stmt.setString(5, despesa.getEspecie());
			                  stmt.setString(6, despesa.getFase());
			                  stmt.setString(7, despesa.getFavorecido());
			                  stmt.setString(8, despesa.getFavorecidoIntermediario());
			                  stmt.setString(9, despesa.getLocalizadorGasto());
			                  stmt.setString(10, despesa.getNomeFavorecido());
			                  stmt.setString(11, despesa.getOrgao());
			                  stmt.setString(12, despesa.getOrgaoSuperior());
			                  stmt.setString(13, despesa.getSubtitulo());
			                  stmt.setString(14, despesa.getUfFavorecido());
			                  stmt.setString(15, despesa.getUg());
			                  stmt.setDouble(16, despesa.getValor());
			                  stmt.setString(17, despesa.getUo());
			                  stmt.setString(18, despesa.getGrupo());
			                  stmt.setString(19, despesa.getElemento());
			                  stmt.setString(20, despesa.getModalidade());
			                  stmt.setString(21, despesa.getFavorecidoListaFaturas());
			                  stmt.setString(22, despesa.getDocumento());
			                  stmt.setString(23, despesa.getDocumentoResumido());
			                  stmt.execute();
			                  stmt.close();
			                  conectado.close();
			                  
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

	}
	
	
	public void criaSubitemEmpenho(despesaPublica despesa){
		
		Connection conectado = getConnection();

		String sql = "UPDATE DESPESAS_PUBLICAS_V2 ";
		sql+= "SET SUBITEM = ?, QUANTIDADE = ?, VALORUNIT = ?, VALORTOTAL = ?, DESCRICAO = ? ";
		sql+= "WHERE DOCUMENTO = ?";

		try {

			PreparedStatement stmt = conectado.prepareStatement(sql);
			stmt.setString(1, despesa.getSubitem());
			stmt.setFloat (2, despesa.getQuantidade());
			stmt.setDouble(3, despesa.getValorUnit());
			stmt.setDouble(4, despesa.getValorTotal());
			stmt.setString(5, despesa.getDescricao());
			stmt.setString(6, despesa.getDocumento());

			stmt.executeUpdate();
			stmt.close();
			conectado.close();

		} catch (SQLException e) {

			e.printStackTrace();
		}       
		
	}
	
	public void criaEmpenhosImpactadosPag(despesaPublica despesa){
			
			Connection conectado = getConnection();
	
			String sql = "UPDATE DESPESAS_PUBLICAS_V2 ";
			sql+= "SET EMPENHO = ?, EMPENHORESUMIDO = ?, VALORLIQUIDADO = ?, VALORPAGO = ?, VALORRESTOINSCRITO = ?, VALORRESTOCANCELADO = ?, VALORRESTOPAGO = ? ";
			sql+= "WHERE DOCUMENTO = ? AND FASE = 'Pagamento' ";
	
			try {
	
				PreparedStatement stmt = conectado.prepareStatement(sql);
				stmt.setString(1, despesa.getEmpenho());
				stmt.setString(2, despesa.getEmpenhoResumido());				
				stmt.setDouble(3, despesa.getValorLiquidado());
				stmt.setDouble(4, despesa.getValorPago());
				stmt.setDouble(5, despesa.getValorRestoInscrito());
				stmt.setDouble(6, despesa.getValorRestoCancelado());
				stmt.setDouble(7, despesa.getValorRestoPago());
				stmt.setString(8, despesa.getDocumento());
	
				stmt.executeUpdate();
				stmt.close();
				conectado.close();
	
			} catch (SQLException e) {
	
				e.printStackTrace();
			}       
			
		}
	
	public void criaEmpenhosImpactadosLiq(despesaPublica despesa){
		
		Connection conectado = getConnection();

		String sql = "UPDATE DESPESAS_PUBLICAS_V2 ";
		sql+= "SET EMPENHO = ?, EMPENHORESUMIDO = ?, VALORLIQUIDADO = ?, VALORPAGO = ?, VALORRESTOINSCRITO = ?, VALORRESTOCANCELADO = ?, VALORRESTOPAGO = ? ";
		sql+= "WHERE DOCUMENTO = ? AND FASE = 'Liquida��o' ";

		try {

			PreparedStatement stmt = conectado.prepareStatement(sql);
			stmt.setString(1, despesa.getEmpenho());
			stmt.setString(2, despesa.getEmpenhoResumido());				
			stmt.setDouble(3, despesa.getValorLiquidado());
			stmt.setDouble(4, despesa.getValorPago());
			stmt.setDouble(5, despesa.getValorRestoInscrito());
			stmt.setDouble(6, despesa.getValorRestoCancelado());
			stmt.setDouble(7, despesa.getValorRestoPago());
			stmt.setString(8, despesa.getDocumento());

			stmt.executeUpdate();
			stmt.close();
			conectado.close();

		} catch (SQLException e) {

			e.printStackTrace();
		}       
		
	}
	
}
