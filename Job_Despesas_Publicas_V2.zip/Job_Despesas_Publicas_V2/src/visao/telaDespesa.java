package visao;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controle.EmpenhosImpactado;
import controle.cliente;
import controle.subitemEmpenho;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import modelo.despesaPublica;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;


public class telaDespesa extends JFrame {

	private JPanel contentPane;
	private JTextField unidG;
	private JTextField dtEmissao;
	private JTextField fase;
	private JTextField pagina;
	private JButton btnNewButton;
	private JLabel lblGestao;
	private JTextField gestao;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaDespesa tp = new telaDespesa();
					
					//tp.executaJob();
					tp.executaJobANO();
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public telaDespesa() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1071, 73);
		contentPane = new JPanel();
		setTitle("Despesas P�blicas");
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setResizable(false);
		
		JLabel lblUnidadeGestora = new JLabel("Unidade Gestora");
		contentPane.add(lblUnidadeGestora, "2, 2, right, default");
		
		unidG = new JTextField();
		contentPane.add(unidG, "4, 2, fill, default");
		unidG.setColumns(10);
		
		lblGestao = new JLabel("Gestao");
		contentPane.add(lblGestao);
		
		gestao = new JTextField();
		contentPane.add(gestao);
		gestao.setColumns(10);
		
		JLabel lblDataEmisso = new JLabel("Data Emiss\u00E3o");
		contentPane.add(lblDataEmisso, "2, 4, right, default");
		
		dtEmissao = new JTextField();
		contentPane.add(dtEmissao, "4, 4, fill, default");
		dtEmissao.setColumns(10);
		
		JLabel lblFase = new JLabel("Fase");
		contentPane.add(lblFase, "2, 6, right, default");
		
		fase = new JTextField();
		contentPane.add(fase, "4, 6, fill, default");
		fase.setColumns(10);
		
		JLabel lblPgina = new JLabel("P\u00E1gina");
		contentPane.add(lblPgina, "2, 8, right, default");
		
		pagina = new JTextField();
		contentPane.add(pagina, "4, 8, fill, default");
		pagina.setColumns(10);
		pagina.setToolTipText("Para executar com todas as paginas, informar 0");					
		
		btnNewButton = new JButton("Executar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
										
				//if (!unidG.getText().equals("") && !dtEmissao.getText().equals("") && !fase.getText().equals("") && !pagina.getText().equals("")){
				if(!dtEmissao.getText().equals("") && !fase.getText().equals("") && !pagina.getText().equals("")){
				
					if (!unidG.getText().equals("") || !gestao.getText().equals("")){
						
						if(pagina.getText().equals("0")){
							
							boolean ok = false; 
							
							for (int i = 1; i <= 99; i++) {
								
								//cliente cli = new cliente();
								
								   //ok = cli.executaAll(unidG.getText(),dtEmissao.getText(),fase.getText(),String.valueOf(i),gestao.getText());
								       
								if(ok == false) break;
								
							}
							JOptionPane.showMessageDialog(null, "Executado com sucesso");
						}
						else{
							
							boolean ok = false; 
							
							//cliente cli = new cliente();
						      
							despesaPublica desp = new despesaPublica();
							
						      //ok =  cli.executa(unidG.getText(),dtEmissao.getText(),fase.getText(),pagina.getText(),gestao.getText(),desp);
						        
						      if(ok == false){
						    	  if(desp.getRetorno().equals("OK")){JOptionPane.showMessageDialog(null,"N�o existe despesa para esta consulta");}
						    	  else {JOptionPane.showMessageDialog(null,desp.getRetorno());}
						      }
						      else{
						    	  JOptionPane.showMessageDialog(null, "Executado com sucesso");
						      }
						}
					}
					else{JOptionPane.showMessageDialog(null, "Deve ser preenchido ao menos o filtro de unidade gestora ou gest�o");}
				}
				else {JOptionPane.showMessageDialog(null,"Deve ser preenchido os campos obrigat�rios data de emiss�o,fase, p�gina e ao menos o filtro unidade gestora ou gest�o","Preenchimento obrigat�rio",JOptionPane.WARNING_MESSAGE);}
			}
		});
				
		contentPane.add(btnNewButton, "4, 10");
			
	}

	/*private void executaJobEmpenho(){
		
		String d3 = retornaDtAtual();			
		ArrayList<String> documentos = new ArrayList<String>();		
		
		boolean ok = false; 
		
		for (int j = 80; j <= 89; j++) {
			
			d3 = retornaData(j);
			
			for (int i = 1; i <= 99; i++) {
				
				cliente cli = new cliente();
				
				   ok = cli.executaAll("393003",d3,"1",String.valueOf(i),"",documentos);
				       
				if(ok == false) break;
				
			}
			
			
			
		}
		
		subitemEmpenho subitemempenho = new subitemEmpenho(); 
	    
		for (int i = 0; i < documentos.size(); i++) {
		
			ok =  subitemempenho.executa(documentos.get(i));
		
		}
		
	}*/
	
	private String retornaData(Integer dia){
		
		Calendar c = Calendar.getInstance();
				
		         dia=dia*-1;
		
				 c.add(Calendar.DATE, dia);							
				 
		//verifica se a data � Sabado
		if (c.get(Calendar.DAY_OF_WEEK) == 7) {c.add(Calendar.DATE, -1);}	
		
		//verifica se a data � Domingo
		if (c.get(Calendar.DAY_OF_WEEK) == 1) {c.add(Calendar.DATE, -2);}				
				 
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
				
		String dtAtual = formato.format(c.getTime());

		return dtAtual;
	}
	
//	private void executaJob(){
//		
//		String d3 = retornaDtAtual();			
//								
//		//analisar cada fase 1- Empenho / 2 - Liquida��o / 3 - Pagamento
//		
//		for (int j = 1; j <= 3; j++) {					 
//			
//			ArrayList<String> documentos = null;
//			
//			//Instancia o array de documentos para atualizar subitem de desempenho e empenhos impactados
//			documentos = new ArrayList<String>(); 
//			
//			//captura informa��es das despesas
//			cliente cli = new cliente();
//			
//		    cli.executaAll(d3,d3,String.valueOf(j),documentos);
//			 
//		    if (j==1) {
//		    
//			    //atualiza os itens da fase de desempenho
//				subitemEmpenho subitemempenho = new subitemEmpenho(); 
//							    
//				for (int i = 0; i < documentos.size(); i++) {
//				
//					subitemempenho.executa(documentos.get(i));
//				
//				}
//		    }
//		    else if (j==2 || j==3){
//		    	
//		    	//atualiza os itens da fase de liquidacao e pagamento
//				EmpenhosImpactado empenhosimpactados = new EmpenhosImpactado();
//				
//				for (int l = 0; l < documentos.size(); l++) {
//					
//					empenhosimpactados.executa(documentos.get(l),j);
//				
//				}
//		    	
//		    }
//		}
//			JOptionPane.showMessageDialog(null, "Executado com sucesso");
//		
//	}
	
	private String retornaDtAtual(){
				
		Calendar c = Calendar.getInstance();
				
				 c.add(Calendar.DATE, -2);							
				 
		//verifica se a data � Sabado
		if (c.get(Calendar.DAY_OF_WEEK) == 7) {c.add(Calendar.DATE, -1);}	
		
		//verifica se a data � Domingo
		if (c.get(Calendar.DAY_OF_WEEK) == 1) {c.add(Calendar.DATE, -2);}				
				 
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
				
		String dtAtual = formato.format(c.getTime());

		return dtAtual;
	}
	
	private void executaJobANO(){
			
		String d3 = retornaDtAtual();			
			
		for (int e = 133; e <= 167; e++) {
			
			d3 = retornaData(e);
			
			//analisar cada fase 1- Empenho / 2 - Liquida��o / 3 - Pagamento			
			for (int j = 1; j <= 3; j++) {					 
				
				ArrayList<String> documentos = null;
				
				//Instancia o array de documentos para atualizar subitem de desempenho e empenhos impactados
				documentos = new ArrayList<String>(); 
				
				//captura informa��es das despesas
				cliente cli = new cliente();
				
			    cli.executaAll(d3,d3,String.valueOf(j),documentos);
				 
			    if (j==1) {
			    
				    //atualiza os itens da fase de desempenho
					subitemEmpenho subitemempenho = new subitemEmpenho(); 
								    
					for (int i = 0; i < documentos.size(); i++) {
					
						subitemempenho.executa(documentos.get(i));
					
					}
			    }
			    else if (j==2 || j==3){
			    	
			    	//atualiza os itens da fase de liquidacao e pagamento
					EmpenhosImpactado empenhosimpactados = new EmpenhosImpactado();
					
					for (int l = 0; l < documentos.size(); l++) {
						
						empenhosimpactados.executa(documentos.get(l),j);
					
					}
			    	
			    }
			}
		}
				JOptionPane.showMessageDialog(null, "Executado com sucesso");
			
		} 
	
}
