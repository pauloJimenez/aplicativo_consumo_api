package controle;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class EmpenhosImpactado {

	private static int HTTP_COD_SUCESSO = 200;		
	
	public EmpenhosImpactado(){
		
	}
	
	//execu��o
	//public boolean  executa(String documento, despesaPublica retorno){
	public void executa(String documento,Integer fase){
		
		String linha = null;		
		
		 try {
			 
		 	lerArqJsonEmpenhosImpactados  lerArq = new lerArqJsonEmpenhosImpactados();
		 
		 	URL url;
		 	
		 	//monta a URL
		 	String url_ = "http://www.transparencia.gov.br/api-de-dados/despesas/empenhos-impactados?codigoDocumento="+documento+"&fase="+fase;
		 			 				 	
	 		    url = new URL(url_);			 	
		 	
		 		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		 		
	            if (con.getResponseCode() != HTTP_COD_SUCESSO) {
	            	throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
	            }
	                
	            BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(),"UTF-8"));		            		            		            		           
	            
	            while ((linha = br.readLine()) != null) { 
	            		
	            	if (!linha.equals("[]")){
		            	lerArq.lerArqJson(linha,documento,fase);		            	
	            	}
	
	             }       
	            //retorno.setRetorno(con.getResponseMessage());
	            con.disconnect();
	      
	        } catch (MalformedURLException e) {
	        	e.printStackTrace();
	        } catch (IOException e) {
	        	e.printStackTrace();
	        }
		 			 
	}
	
}
