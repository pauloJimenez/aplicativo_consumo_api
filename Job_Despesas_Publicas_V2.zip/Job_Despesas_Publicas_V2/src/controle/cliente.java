package controle;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


import java.util.ArrayList;

//import modelo.despesaPublica;


public class cliente {

	private static int HTTP_COD_SUCESSO = 200;		
	public  ArrayList<String> documentos = null;
	
	public cliente(){
		
	}
		
		//executa 
		public void  executaAll(String dtEm_ini,String dtEm_fim, String fase,ArrayList<String> documentos){
			
			String linha1 = null;
         
			//boolean ok = false; 
			
			 try {
				 
				 	lerArqJson  lerArq = new lerArqJson();
				 
				 	URL url1;
				 	
				 	String url_ = "http://www.portaltransparencia.gov.br/despesas/favorecido/resultado?paginacaoSimples=false&tamanhoPagina=1000&offset=0&direcaoOrdenacao=asc&colunaOrdenacao=fase&";
				 	       url_+= "colunasSelecionadas=data,documentoResumido,localizadorGasto,fase,especie,favorecido,ufFavorecido,valor,ug,uo,orgao,orgaoSuperior,grupo,elemento,modalidade&";
				 	
				 	//monta a URL 
				 	
		 	       //data emissao inicial			 		
		 		   url_+= "de="+dtEm_ini;
		 		
		 		   //data emissao final				 		
		 		   url_+= "&ate="+dtEm_fim;
		 						 	
		 		   //fase Empenho	
		 		   url_+= "&faseDespesa="+fase;				 						 					        
				 		
		 		   //elemento 51
		 		   url_+= "&elemento=51";
		 		   
				   url1 = new URL(url_);			 	
				 	
				   HttpURLConnection con = (HttpURLConnection) url1.openConnection();		 				 		
		 		
		           if (con.getResponseCode() != HTTP_COD_SUCESSO) {
		               throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
		           }
 
                
		           BufferedReader br1 = new BufferedReader(new InputStreamReader(con.getInputStream(),"UTF-8"));
	           
	         			            	
		           while ((linha1 = br1.readLine()) != null ) {   	              	                
		        	   if (!linha1.equals("[]")){
		        		   lerArq.lerArqJson(linha1,documentos);
		        		   
		        	   }
		           } 
	            			           
		           con.disconnect();
 			            
			            
		        } catch (MalformedURLException e) {
		            e.printStackTrace();
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
			 			 
		}
	
	
}
