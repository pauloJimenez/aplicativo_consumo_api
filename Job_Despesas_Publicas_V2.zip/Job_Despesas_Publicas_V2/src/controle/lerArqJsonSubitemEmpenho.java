package controle;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import DAO.*;

import com.google.gson.Gson;

import modelo.*;

public class lerArqJsonSubitemEmpenho {
			
	despesa d;
	despesaPublica despesa;
	
    public lerArqJsonSubitemEmpenho(){
    	
    	
    }
	
	public void lerArqJson(String dadosJson,String documento){
		
		//conecta com o BD
		DAO dao = new DAO();				
		
		Gson gson = new Gson();
		
		//separa os dados do retorno do JSON
		String regex = "\\{.*?\\}";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(dadosJson);				
					
		while (m.find()) {
			
			d = gson.fromJson(m.group(), despesa.class);  			
			
			despesa = new despesaPublica();						
			
			despesa.setSubitem(d.subitem);
			despesa.setQuantidade(d.quantidade);
			despesa.setValorUnit(converteStringDouble(d.valorUnit));
			despesa.setValorTotal(converteStringDouble(d.valorTotal));
			despesa.setDescricao(d.descricao);
			despesa.setDocumento(documento);
						
			//atualiza a despesa no BD
			dao.criaSubitemEmpenho(despesa);
			
	}
	
	
}

	class despesa{
		
		String subitem;
		Float quantidade;
		String valorUnit;
		String valorTotal;
		String descricao;
		String documento;
	}
	
		
	private Double converteStringDouble(String vlString){
		
		Double vldouble;
		
		if (vlString != null) vlString = vlString.replace(".","").replace(",",".").replace(" ","");
		else vlString = "";
		
		if(!vlString.equals("")) vldouble = Double.parseDouble(vlString);
		else vldouble = (double) 0;
		
		return vldouble;
	}
}
