package controle;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import DAO.*;

import com.google.gson.Gson;

import modelo.*;

public class lerArqJsonEmpenhosImpactados {
			
	despesa d;
	despesaPublica despesa;
	
    public lerArqJsonEmpenhosImpactados(){
    	
    	
    }
	
	public void lerArqJson(String dadosJson,String documento,Integer fase){
		
		//conecta com o BD
		DAO dao = new DAO();				
		
		Gson gson = new Gson();
		
		//separa os dados do retorno do JSON
		String regex = "\\{.*?\\}";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(dadosJson);				
					
		while (m.find()) {
			
			d = gson.fromJson(m.group(), despesa.class);  			
			
			despesa = new despesaPublica();						
			
			despesa.setEmpenho(d.empenho);
			despesa.setEmpenhoResumido(d.empenhoResumido);
			despesa.setValorLiquidado(converteStringDouble(d.valorLiquidado));
			despesa.setValorPago(converteStringDouble(d.valorPago));
			despesa.setValorRestoInscrito(converteStringDouble(d.valorRestoInscrito));
			despesa.setValorRestoCancelado(converteStringDouble(d.valorRestoCancelado));
			despesa.setValorRestoPago(converteStringDouble(d.valorRestoPago));						
			despesa.setDocumento(documento);
						
			//atualiza a despesa no BD			
			if (fase == 2) dao.criaEmpenhosImpactadosLiq(despesa);
			if (fase == 3) dao.criaEmpenhosImpactadosPag(despesa);
			
	}
	
	
}

	class despesa{
		
		String empenho;
		String empenhoResumido;
		String valorLiquidado;
		String valorPago;
		String valorRestoInscrito;
		String valorRestoCancelado;
		String valorRestoPago;
		String documento;
	}
	
		
	private Double converteStringDouble(String vlString){
		
		Double vldouble;
		
		if (vlString != null) vlString = vlString.replace(".","").replace(",",".").replace(" ","");
		else vlString = "";
		
		if(!vlString.equals("")) vldouble = Double.parseDouble(vlString);
		else vldouble = (double) 0;
		
		return vldouble;
	}
}
