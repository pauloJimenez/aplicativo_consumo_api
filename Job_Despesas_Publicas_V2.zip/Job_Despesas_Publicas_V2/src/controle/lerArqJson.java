package controle;


import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import DAO.*;

import com.google.gson.Gson;

import modelo.*;

public class lerArqJson {
					
	private	despesa           d;
	private	despesaPublica    despesa;
		   
    public lerArqJson(){
    	
    	
    }
	
	public void lerArqJson(String dadosJson,ArrayList<String> documentos){
		
		//conecta com o BD
		DAO dao = new DAO();				
		
		Gson gson = new Gson();
		
		//
		String conteudoJason = capturaDadosJason(dadosJson);
		
		//separa os dados do retorno do JSON
		String regex = "\\{.*?\\}";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(conteudoJason);				
					
		while (m.find()) {
			
			d = gson.fromJson(m.group(), despesa.class);  			
			
			despesa = new despesaPublica();						
			
			despesa.setCodigoFavorecido(d.codigoFavorecido);
			despesa.setData(converteStringData(d.data));
			despesa.setDocumento(d.documento);
			despesa.setDocumentoResumido(d.documentoResumido);
			despesa.setEspecie(d.especie);
			despesa.setFase(d.fase);
			despesa.setFavorecido(d.favorecido);
			despesa.setFavorecidoIntermediario(d.favorecidoIntermediario);
			despesa.setLocalizadorGasto(d.localizadorGasto);
			despesa.setNomeFavorecido(d.nomeFavorecido);
			despesa.setOrgao(d.orgao);
			despesa.setOrgaoSuperior(d.orgaoSuperior);
			despesa.setSubtitulo(d.subtitulo);
			despesa.setUfFavorecido(d.ufFavorecido);
			despesa.setUg(d.ug);
			despesa.setUo(d.uo);
			despesa.setGrupo(d.grupo);
			despesa.setElemento(d.elemento);
			despesa.setModalidade(d.modalidade);
			despesa.setFavorecidoListaFaturas(d.favorecidoListaFaturas);
			despesa.setValor(converteStringDouble(d.valor.replace(".","").replace(",",".").replace(" ","")));
			
			//atualiza a despesa no BD
			dao.criadespesa(despesa);
				
			//preenche o array de documentos
			 preencheDocumentos(documentos,d.documento);
	}
	
	
}

	class despesa{
		
		String codigoFavorecido;
		String data;
		String documento;
		String documentoResumido; 
		String especie; 
		String fase; 
		String favorecido;	
		String favorecidoIntermediario;
		String localizadorGasto;
		String nomeFavorecido;
		String orgao;
		String orgaoSuperior;
		String subtitulo;
		String ufFavorecido;
		String ug;
		String uo;
		String grupo;
		String elemento;
		String modalidade;
		String favorecidoListaFaturas;
		String valor;

	}
	
	private Date converteStringData(String dtString)
	{
		Date dtDate = null;				
		
		try{
			dtDate = new Date(new SimpleDateFormat("dd/MM/yyyy").parse(dtString).getTime());
		}
		catch(Exception e){
			e.printStackTrace();
		}	
		
		return dtDate;
	}
	
	private Double converteStringDouble(String vlString){
		
		Double vldouble;
		
		if(!vlString.equals("")) vldouble = Double.parseDouble(vlString);
		else vldouble = (double) 0;
		
		return vldouble;
	}
	
	private void preencheDocumentos(ArrayList<String> documentos,String documento){
		
		documentos.add(documento);
		
	}
	
	private String capturaDadosJason(String dados){
		
		int indice_i = dados.indexOf('[');
		int indice_f = dados.indexOf(']');
		
		String conteudo = dados.substring(indice_i, indice_f);
		
		return conteudo;
		
	}	
	
}
