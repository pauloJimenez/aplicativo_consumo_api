package modelo;

import java.sql.Date;

public class despesaPublica {

	String codigoFavorecido;
	Date data;
	String documento;
	String documentoResumido; 
	String especie; 
	String fase; 
	String favorecido;	
	String favorecidoIntermediario;
	String localizadorGasto;
	String nomeFavorecido;
	String orgao;
	String orgaoSuperior;
	String subtitulo;
	String ufFavorecido;
	String ug;
	String uo;
	String grupo;
	String elemento;
	String modalidade;
	String favorecidoListaFaturas;
	Double valor;
	String retorno;
	String subitem;
	Float quantidade;
	Double valorUnit;
	Double valorTotal;
	String descricao;
	String empenho;
	String empenhoResumido;
	Double valorLiquidado;
	Double valorPago;
	Double valorRestoInscrito;
	Double valorRestoCancelado;
	Double valorRestoPago;
	
	
	public String getCodigoFavorecido() {
		return codigoFavorecido;
	}
	public void setCodigoFavorecido(String codigoFavorecido) {
		this.codigoFavorecido = codigoFavorecido;
	}
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
	public String getDocumento() {
		return documento;
	}
	public void setDocumento(String documento) {
		this.documento = documento;
	}
	public String getDocumentoResumido() {
		return documentoResumido;
	}
	public void setDocumentoResumido(String documentoResumido) {
		this.documentoResumido = documentoResumido;
	}
	public String getEspecie() {
		return especie;
	}
	public void setEspecie(String especie) {
		this.especie = especie;
	}
	public String getFase() {
		return fase;
	}
	public void setFase(String fase) {
		this.fase = fase;
	}
	public String getFavorecido() {
		return favorecido;
	}
	public void setFavorecido(String favorecido) {
		this.favorecido = favorecido;
	}
	public String getFavorecidoIntermediario() {
		return favorecidoIntermediario;
	}
	public void setFavorecidoIntermediario(String favorecidoIntermediario) {
		this.favorecidoIntermediario = favorecidoIntermediario;
	}
	public String getLocalizadorGasto() {
		return localizadorGasto;
	}
	public void setLocalizadorGasto(String localizadorGasto) {
		this.localizadorGasto = localizadorGasto;
	}
	public String getNomeFavorecido() {
		return nomeFavorecido;
	}
	public void setNomeFavorecido(String nomeFavorecido) {
		this.nomeFavorecido = nomeFavorecido;
	}
	public String getOrgao() {
		return orgao;
	}
	public void setOrgao(String orgao) {
		this.orgao = orgao;
	}
	public String getOrgaoSuperior() {
		return orgaoSuperior;
	}
	public void setOrgaoSuperior(String orgaoSuperior) {
		this.orgaoSuperior = orgaoSuperior;
	}
	public String getSubtitulo() {
		return subtitulo;
	}
	public void setSubtitulo(String subtitulo) {
		this.subtitulo = subtitulo;
	}
	public String getUfFavorecido() {
		return ufFavorecido;
	}
	public void setUfFavorecido(String ufFavorecido) {
		this.ufFavorecido = ufFavorecido;
	}
	public String getUg() {
		return ug;
	}
	public void setUg(String ug) {
		this.ug = ug;
	}
	public Double getValor() {
		return valor;
	}
	public void setValor(Double valor) {
		this.valor = valor;
	}
	public String getRetorno() {
		return retorno;
	}
	public void setRetorno(String retorno) {
		this.retorno = retorno;
	}
	public String getSubitem() {
		return subitem;
	}
	public void setSubitem(String subitem) {
		this.subitem = subitem;
	}
	public Float getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(Float quantidade) {
		this.quantidade = quantidade;
	}
	public Double getValorUnit() {
		return valorUnit;
	}
	public void setValorUnit(Double valorUnit) {
		this.valorUnit = valorUnit;
	}
	public Double getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(Double valorTotal) {
		this.valorTotal = valorTotal;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getUo() {
		return uo;
	}
	public void setUo(String uo) {
		this.uo = uo;
	}
	public String getGrupo() {
		return grupo;
	}
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}
	public String getElemento() {
		return elemento;
	}
	public void setElemento(String elemento) {
		this.elemento = elemento;
	}
	public String getModalidade() {
		return modalidade;
	}
	public void setModalidade(String modalidade) {
		this.modalidade = modalidade;
	}
	public String getFavorecidoListaFaturas() {
		return favorecidoListaFaturas;
	}
	public void setFavorecidoListaFaturas(String favorecidoListaFaturas) {
		this.favorecidoListaFaturas = favorecidoListaFaturas;
	}
	public String getEmpenho() {
		return empenho;
	}
	public void setEmpenho(String empenho) {
		this.empenho = empenho;
	}
	public String getEmpenhoResumido() {
		return empenhoResumido;
	}
	public void setEmpenhoResumido(String empenhoResumido) {
		this.empenhoResumido = empenhoResumido;
	}
	public Double getValorLiquidado() {
		return valorLiquidado;
	}
	public void setValorLiquidado(Double valorLiquidado) {
		this.valorLiquidado = valorLiquidado;
	}
	public Double getValorPago() {
		return valorPago;
	}
	public void setValorPago(Double valorPago) {
		this.valorPago = valorPago;
	}
	public Double getValorRestoInscrito() {
		return valorRestoInscrito;
	}
	public void setValorRestoInscrito(Double valorRestoInscrito) {
		this.valorRestoInscrito = valorRestoInscrito;
	}
	public Double getValorRestoCancelado() {
		return valorRestoCancelado;
	}
	public void setValorRestoCancelado(Double valorRestoCancelado) {
		this.valorRestoCancelado = valorRestoCancelado;
	}
	public Double getValorRestoPago() {
		return valorRestoPago;
	}
	public void setValorRestoPago(Double valorRestoPago) {
		this.valorRestoPago = valorRestoPago;
	}
	

}
